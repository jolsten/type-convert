#define APPEND_UNDERSCORE
#include "to_vax_h16.c"
