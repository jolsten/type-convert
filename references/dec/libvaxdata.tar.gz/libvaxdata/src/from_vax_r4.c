#if defined( __VMS ) && defined( __DECC )
#pragma module from_vax_r4
#endif
#define MAKE_FROM_VAX_R4
#include "convert_vax_data.c"
