#if defined( __VMS ) && defined( __DECC )
#pragma module from_vax_d8
#endif
#define MAKE_FROM_VAX_D8
#include "convert_vax_data.c"
