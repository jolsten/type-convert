#define APPEND_UNDERSCORE
#include "is_little_endian.c"
