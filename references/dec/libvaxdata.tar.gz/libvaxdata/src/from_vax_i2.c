#if defined( __VMS ) && defined( __DECC )
#pragma module from_vax_i2
#endif
#define MAKE_FROM_VAX_I2
#include "convert_vax_data.c"
