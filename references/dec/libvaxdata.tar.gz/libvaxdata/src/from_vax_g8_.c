#define APPEND_UNDERSCORE
#include "from_vax_g8.c"
