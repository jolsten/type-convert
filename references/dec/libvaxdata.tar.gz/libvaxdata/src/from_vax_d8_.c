#define APPEND_UNDERSCORE
#include "from_vax_d8.c"
