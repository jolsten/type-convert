#if defined( __VMS ) && defined( __DECC )
#pragma module to_vax_r4
#endif
#define MAKE_TO_VAX_R4
#include "convert_vax_data.c"
